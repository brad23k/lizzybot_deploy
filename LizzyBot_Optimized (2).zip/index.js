
require('dotenv').config();
const { Telegraf } = require('telegraf');
const { Configuration, OpenAIApi } = require('openai');
const express = require('express');
const mongoose = require('mongoose');
const cron = require('node-cron');
const axios = require('axios');
const moment = require('moment');
const FormData = require('form-data');
const ffmpeg = require('fluent-ffmpeg');
const path = require('path');

const app = express();
const bot = new Telegraf(process.env.TELEGRAM_TOKEN);
const openai = new OpenAIApi(new Configuration({ apiKey: process.env.OPENAI_KEY }));

mongoose.connect(process.env.MONGO_URI);

bot.start((ctx) => ctx.reply(`Hey I'm ${process.env.BOT_NAME}, your AI companion.`));

bot.on('text', async (ctx) => {
    const res = await openai.createChatCompletion({
        model: "gpt-4",
        messages: [{ role: "user", content: ctx.message.text }]
    });
    ctx.reply(res.data.choices[0].message.content);
});

bot.launch();
app.listen(process.env.PORT || 3000, () => console.log("Server running"));
