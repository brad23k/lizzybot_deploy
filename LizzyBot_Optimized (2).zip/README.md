
# LizzyBot

## How to Deploy

1. Upload all files to GitHub.
2. Connect repo to Render.
3. Set up environment variables from `.env.example`.
4. Hit 'Deploy' on Render.

Your AI-powered Telegram bot will be live and earning!
